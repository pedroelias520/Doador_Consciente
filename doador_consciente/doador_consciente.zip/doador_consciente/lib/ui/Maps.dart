import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class MapsPage extends StatefulWidget {
  @override
  _MapsPageState createState() => _MapsPageState();
}

class _MapsPageState extends State<MapsPage> {
  List<DropdownMenuItem<String>> listDrop = [];
  String selected = null;

  void LoadData() {
    listDrop = [];
    listDrop.add(new DropdownMenuItem(
      child: Text("Hemocentro:Floriano"),
      value: "one" ,

    ));
    listDrop.add(new DropdownMenuItem(
      child: Text("Hemocentro:Picos"),
      value: "two" ,

    ));
    listDrop.add(new DropdownMenuItem(
      child: Text("Hemocentro:Parnaíba"),
      value: "three" ,
    ));
    listDrop.add(new DropdownMenuItem(
      child: Text("Hemocentro:Teresina"),
      value: "four" ,

    ));
  }


  GoogleMapController mapController;

  String buscarDireccion;

  @override
  Widget build(BuildContext context) {
    LoadData();
    return Stack(
      children: <Widget>[
        GoogleMap(
          onMapCreated: onMapCreated,
          options: GoogleMapOptions(
              cameraPosition: CameraPosition(
                  target: LatLng(21.1193733, -86.809402),
                  zoom: 15.0)
          ),
        ),
        Positioned(
          top: 30.0,
          right: 15.0,
          left: 15.0,
          child: Container(
            height: 50.0,
            width: double.infinity,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                color: Colors.white
            ),
            child:
            DropdownButton(
                iconSize: 40.0,
                elevation: 15,
                value: selected,
                items: listDrop,
                onChanged: (value) {
                  selected = value;
                  buscarDireccion = selected;
                  setState(() {

                  });
                }

            )

            ,

          ),
        )
      ],
    );
  }


  barraBusqueda_Teresina() {
    Geolocator().placemarkFromAddress(buscarDireccion).then((result) {
      mapController.animateCamera(
          CameraUpdate.newCameraPosition(CameraPosition(
              target:
              LatLng(
                  result[0].position.latitude, result[0].position.longitude),
              zoom: 10.0)));
    });
  }

  barraBusqueda_Floriano() {
    Geolocator().placemarkFromAddress(buscarDireccion).then((result) {
      mapController.animateCamera(
          CameraUpdate.newCameraPosition(CameraPosition(
              target:
              LatLng(
                  result[0].position.latitude, result[0].position.longitude),
              zoom: 10.0)));
    });
  }

  barraBusqueda_Picos() {
    Geolocator().placemarkFromAddress(buscarDireccion).then((result) {
      mapController.animateCamera(
          CameraUpdate.newCameraPosition(CameraPosition(
              target:
              LatLng(
                  result[0].position.latitude, result[0].position.longitude),
              zoom: 10.0)));
    });
  }

  barraBusqueda_Parnaiba() {
    Geolocator().placemarkFromAddress(buscarDireccion).then((result) {
      mapController.animateCamera(
          CameraUpdate.newCameraPosition(CameraPosition(
              target:
              LatLng(
                  result[0].position.latitude, result[0].position.longitude),
              zoom: 10.0)));
    });
  }

  void onMapCreated(controller) {
    setState(() {
      mapController = controller;
    });
  }
}
