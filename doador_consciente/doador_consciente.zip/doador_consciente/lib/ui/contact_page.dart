import 'dart:async';
import 'dart:io';

import 'package:doador_consciente/helpers/contact_helper.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'home_page.dart';

class ContactPage extends StatefulWidget {
  final Contact contact;

  ContactPage({this.contact});

  @override
  _ContactPageState createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> {
  List<Contact> contacts = List();
  List<Contact> contacts2 = List();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _tipoSangueController = TextEditingController();
  final _localizacaoController = TextEditingController();
  final _tipoController = TextEditingController();
  final _necessidadeController = TextEditingController();
  final _nameFocus = FocusNode();
  ContactHelper helper = ContactHelper();

  bool _userEdited = false, doador = null, habilitacao;
  int _groupValue;
  Contact _editedContact;
  final Color activecolor = Colors.red;

  @override
  void initState() {
    super.initState();
    _getAllContacts();
    habilitacao = false;
    _groupValue = 0;
    if (widget.contact == null) {
      _editedContact = Contact();
    } else {
      _editedContact = Contact.fromMap(widget.contact.toMap());
      _nameController.text = _editedContact.name;
      _emailController.text = _editedContact.email;
      _phoneController.text = _editedContact.phone;
      _tipoSangueController.text = _editedContact.tipoSangue;
      _localizacaoController.text = _editedContact.localizacao;
      _tipoController.text = _editedContact.tipo;
      _necessidadeController.text = _editedContact.necessidade;
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _requestPop,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          title: Text(_editedContact.name ?? "Novo Doador ou Paciente"),
          centerTitle: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [
                  Color.fromRGBO(255, 0, 0, 255),
                  Color.fromRGBO(255, 200, 0, 60)
                ],
              ),
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            if (_editedContact.name != null &&
                _editedContact.name.isNotEmpty &&
                _groupValue != null) {
              //Navigator.pop(context, _editedContact);
              try {
                helper.saveContact(_editedContact);
              } on Exception {
                AlertDialog(
                  title: Text("Erro"),
                  content: Text("Erro de Banco de Aqui!"),
                );
              }
              HomePage(
                contact: _editedContact,
              );
              showHomePage(context: context, contact: _editedContact);
            } else if (_groupValue == null) {
              AlertDialog(
                title: Text("Algo de errado,não está certo..."),
                content: Text("Você precisa especificar o seu tipo"),
              );
            } else {
              FocusScope.of(context).requestFocus(_nameFocus);
            }
            String tipo = _editedContact.tipo;
            String necessidade = _editedContact.necessidade;
            AlertDialog(
              title: Text("Mostragem"),
              content: Text("Tipo:$tipo Necessidade:$necessidade"),
            );
          },
          child: Icon(Icons.save),
          backgroundColor: Colors.red,
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(10.0),
          child: Column(
            children: <Widget>[
              GestureDetector(
                child: Container(
                  width: 140.0,
                  height: 140.0,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                        image: _editedContact.img != null
                            ? FileImage(File(_editedContact.img))
                            : AssetImage("images/person.png"),
                        fit: BoxFit.cover),
                  ),
                ),
                onTap: () {
                  ImagePicker.pickImage(source: ImageSource.camera)
                      .then((file) {
                    if (file == null) return;
                    setState(() {
                      _editedContact.img = file.path;
                    });
                  });
                },
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(color: Colors.grey, width: 1.0))),
                child: TextField(
                  controller: _nameController,
                  focusNode: _nameFocus,
                  decoration: InputDecoration(labelText: "Nome"),
                  onChanged: (text) {
                    _userEdited = true;
                    setState(() {
                      _editedContact.name = text;
                    });
                  },
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(color: Colors.grey, width: 1.0))),
                child: TextField(
                  controller: _emailController,
                  decoration: InputDecoration(labelText: "Email"),
                  onChanged: (text) {
                    _userEdited = true;
                    _editedContact.email = text;
                  },
                  keyboardType: TextInputType.emailAddress,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(color: Colors.grey, width: 1.0))),
                child: TextField(
                  controller: _phoneController,
                  decoration: InputDecoration(labelText: "Phone"),
                  onChanged: (text) {
                    _userEdited = true;
                    _editedContact.phone = text;
                  },
                  keyboardType: TextInputType.phone,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(color: Colors.grey, width: 1.0))),
                child: TextField(
                  controller: _tipoSangueController,
                  decoration: InputDecoration(labelText: "Tipo Sanguíneo"),
                  onChanged: (text) {
                    _userEdited = true;
                    _editedContact.tipoSangue = text;
                  },
                  keyboardType: TextInputType.text,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(color: Colors.grey, width: 1.0))),
                child: TextField(
                  controller: _localizacaoController,
                  decoration: InputDecoration(labelText: "Localização"),
                  onChanged: (text) {
                    _userEdited = true;
                    _editedContact.localizacao = text;
                  },
                  keyboardType: TextInputType.text,
                ),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(color: Colors.grey, width: 1.0))),
                child: TextField(
                  enabled: habilitacao,
                  controller: _necessidadeController,
                  decoration: InputDecoration(labelText: "Necessidade(Bolsas)"),
                  onChanged: (text) {
                    _userEdited = true;
                    _editedContact.necessidade = text;
                  },
                  keyboardType: TextInputType.number,
                ),
              ),
              ButtonBar(
                alignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "Doador",
                    style: TextStyle(color: Colors.black, fontSize: 17.0),
                  ),
                  Radio(
                    activeColor: activecolor,
                    value: 1,
                    groupValue: _groupValue,
                    onChanged: (int e) => tipoDoador(e),
                  ),
                  Text("Paciente",
                      style: TextStyle(color: Colors.black, fontSize: 17.0)),
                  Radio(
                    activeColor: activecolor,
                    value: 2,
                    groupValue: _groupValue,
                    onChanged: (int e) => tipoDoador(e),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _requestPop() {
    if (_userEdited) {
      showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text("Descartar Alterações?"),
              content: Text("Se sair as alterações serão perdidas."),
              actions: <Widget>[
                FlatButton(
                  child: Text("Cancelar"),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
                FlatButton(
                  child: Text("Sim"),
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                ),
              ],
            );
          });
      return Future.value(false);
    } else {
      return Future.value(true);
    }
  }

  void showHomePage({Contact contact, BuildContext context}) async {
    final recContact = await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => HomePage(
            contact: contact,
          )),
    );
    if (recContact != null) {
      if (contact != null) {
        await helper.updateContact(recContact);
      } else {
        await helper.saveContact(recContact);
      }
      _getAllContacts();
      _getAllPacients();
    }
  }

  void _getAllContacts() {
    helper.getAllContacts().then((list) {
      setState(() {
        contacts = list;
      });
    });
  }

  void _getAllPacients() {
    helper.getAllPacients().then((list) {
      setState(() {
        contacts2 = list;
      });
    });
  }

  void tipoDoador(int e) {
    setState(() {
      if (e == 1) {
        String verdadeiro = "true";
        _editedContact.tipo = verdadeiro;
        _groupValue = e;
      } else if (e == 2) {
        String falso = "false";
        _editedContact.tipo = falso;
        _groupValue = e;
        habilitacao = true;
      }
    });
  }
}
