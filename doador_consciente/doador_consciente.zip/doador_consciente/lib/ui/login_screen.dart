
import 'package:doador_consciente/helpers/contact_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart';

import 'contact_page.dart';
import 'home_page.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  ContactHelper helper = ContactHelper();
  List<Contact> contacts = List();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(255, 0, 0, 40.0),
        title: Text("Doe Sangue"),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                Color.fromRGBO(255, 0, 0,255),
                Color.fromRGBO(255, 200, 0, 60)
              ],
            ),
          ),
        ),
      ),
      body: Stack(children: <Widget>[
        Center(
          child: new Image.asset(
            'images/doacao.jpg',
            width: 1000.0,
            height: 1000.0,
            fit: BoxFit.cover,
          ),
        ),
        SingleChildScrollView(
          padding: EdgeInsets.only(left: 10.0, right: 10.0),
          child: Form(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Icon(
                    Icons.account_circle,
                    size: 140.0,
                    color: Color.fromRGBO(255, 0, 0, 40.0),
                  ),
                  TextFormField(
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      icon: Icon(
                        Icons.person,
                        color: Colors.white,
                      ),
                      border: InputBorder.none,
                      labelText: "Login",
                      hintStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 60.0,
                      ),
                    ),
                  ),
                  TextFormField(
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      icon: Icon(
                        Icons.lock_outline,
                        color: Colors.white,
                      ),
                      labelText: "Senha",
                      border: InputBorder.none,
                      hintStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 60.0,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                    child: Container(
                      height: 50.0,
                      child: RaisedButton(
                        onPressed: () {
                          showHomePage(context: context);
                        },
                        child: Text(
                          "Entrar",
                          style: TextStyle(color: Colors.white, fontSize: 25.0),
                        ),
                        color: Color.fromRGBO(255, 0, 0, 60.0),
                      ),
                    ),
                  ),
                  Text(
                    "OU",
                    style: TextStyle(
                      fontSize: 30.0,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                    child: Container(
                      height: 50.0,
                      child: RaisedButton(
                        onPressed: () {
                          showCadastroPage(context: context);
                        },
                        child: Text(
                          "Cadastre-se",
                          style: TextStyle(color: Colors.white, fontSize: 25.0),
                        ),
                        color: Color.fromRGBO(255, 0, 0, 60.0),
                      ),
                    ),
                  )
                ],
              )),
        )
      ]),
    );


  }
  void showCadastroPage({Contact contact,BuildContext context}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ContactPage(
            contact: contact,
          )),
    );
  }

  void showHomePage({Contact contact,BuildContext context}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => HomePage(
            contact: contact,
          )),
    );
  }
}
/*void _showContactPage({Contact contact}) async {
    final recContact = await Navigator.push(context,
        MaterialPageRoute(builder: (context) => ContactPage(contact: contact,))
    );
    if(recContact != null){
      if(contact != null){
        await helper.updateContact(recContact);
      } else {
        await helper.saveContact(recContact);
      }
      _getAllContacts();
    }
  }
  void _getAllContacts(){
    helper.getAllContacts().then((list){
      setState(() {
        contacts = list;
      });
    });
  }*/
